package com.rest.restfulwebservices.controller;

import java.net.URI;
import java.util.List;
import java.util.Locale;

import javax.validation.Valid;
import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.linkTo;
import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.methodOn;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.hateoas.EntityModel;
import org.springframework.hateoas.server.mvc.WebMvcLinkBuilder;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import com.rest.restfulwebservices.dao.WebRepo;
import com.rest.restfulwebservices.entity.Customer;
import com.rest.restfulwebservices.exception.CustomerNotFoundException;
import com.rest.restfulwebservices.exception.DataEnteredException;

@RestController
public class RestController1 {

	@Autowired
	private WebRepo webRepo;
	@Autowired
	private MessageSource messageSource; 
	
	@GetMapping("/hellointrn")
	public String hello(@RequestHeader(name = "Accepted-lanugage",required = false) Locale locale) {
		return messageSource.getMessage("good.morning.message", null,locale);
	}
//	@GetMapping("/hellointrn")
//	public String hello() {
//		return messageSource.getMessage("good.morning.message", null,LocaleContextHolder.getLocale());
//	}
	
	@GetMapping("/findAll")
	public List<Customer> findAll() {
		return webRepo.findAll();
	}

	@GetMapping("/user/{id}")
	public EntityModel<Customer> find(@PathVariable int id) {
		Customer customer = webRepo.find(id);
		if (customer == null)
			throw new CustomerNotFoundException("Customer id : " + id + " not found");
		EntityModel<Customer> resource = EntityModel.of(customer);

		WebMvcLinkBuilder linkTo = linkTo(methodOn(this.getClass()).findAll());
		// add the link to resourse with a name : all-users
		resource.add(linkTo.withRel("all-users"));
		return resource;
	}

	@PostMapping("/user")
	public ResponseEntity<Object> cust(@Valid @RequestBody Customer customer, BindingResult bindingResult) {
		if (bindingResult.hasErrors()) {
			throw new DataEnteredException("Enter the data correct data");
		}
		Customer customer2 = webRepo.save(customer);
		URI uri = ServletUriComponentsBuilder.fromCurrentRequest().path("/{id}").buildAndExpand(customer2.getId())
				.toUri();
		return ResponseEntity.created(uri).build();

	}

	@DeleteMapping("/user/{id}")
	public ResponseEntity<Object> delete(@PathVariable int id) {
		Customer customer = webRepo.delete(id);
		if (customer == null)
			throw new CustomerNotFoundException("Customer id : " + id + " not found");
		return ResponseEntity.noContent().build();
	}
}
