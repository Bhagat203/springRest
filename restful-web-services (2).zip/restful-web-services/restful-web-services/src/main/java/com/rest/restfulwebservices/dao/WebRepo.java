package com.rest.restfulwebservices.dao;

import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;

import com.rest.restfulwebservices.entity.Customer;

@Component
public class WebRepo {

	private  static int count=3;
	private static List<Customer> users= new ArrayList<Customer>(); 
	static {
		users.add(new Customer(1,"raj",new Date()));
		users.add(new Customer(2,"ram",new Date()));
	}
	public Customer save(Customer customer) {
		if(customer.getId()==null)
			customer.setId(++count);
		users.add(customer);
		return customer;
	}
	public List<Customer> findAll(){
		return users;
	}
	public Customer find(int id) {
		for (Customer customer : users) {
			if(customer.getId()==id)
				return customer;
		}
		return null;
	}
	public Customer delete(int id) {
		Iterator<Customer> iterator = users.iterator();
		while (iterator.hasNext()) {
			Customer customer = (Customer) iterator.next();
			if(customer.getId()==id) {
				iterator.remove();
				return customer;
			}
		}
		return null;
	}
}
